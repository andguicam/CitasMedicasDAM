package com.dam.citasmedicas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AgregarCita extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_cita);
    }
}