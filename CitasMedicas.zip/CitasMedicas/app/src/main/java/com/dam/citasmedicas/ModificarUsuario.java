package com.dam.citasmedicas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ModificarUsuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_usuario);
    }
}